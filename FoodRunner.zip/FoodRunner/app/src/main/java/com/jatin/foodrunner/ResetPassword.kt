package com.jatin.foodrunner

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class ResetPassword : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_reset_password)

        supportActionBar?.hide()
    }
}