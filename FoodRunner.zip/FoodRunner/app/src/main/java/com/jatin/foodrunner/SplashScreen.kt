package com.jatin.foodrunner

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.view.WindowManager
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class SplashScreen : AppCompatActivity() {

    lateinit var topAnim : Animation

    lateinit var  bottomAnim : Animation

    lateinit var imgLogo: ImageView

    lateinit var txtName: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        supportActionBar?.hide()
        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
        setContentView(R.layout.activity_splash)

        imgLogo = findViewById(R.id.imgLogo)

        txtName = findViewById(R.id.txtName)

        topAnim = AnimationUtils.loadAnimation(this@SplashScreen,R.anim.top_animation)

        bottomAnim = AnimationUtils.loadAnimation(this@SplashScreen,R.anim.bottom_animation)

        imgLogo.startAnimation(topAnim)

        txtName.startAnimation(bottomAnim)

        Handler().postDelayed({ run{

            val i = Intent(this@SplashScreen,LoginActivity::class.java)
            startActivity(i)
            finish()

        } },2500)

    }
}