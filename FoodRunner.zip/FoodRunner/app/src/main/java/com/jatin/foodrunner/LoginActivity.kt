package com.jatin.foodrunner

import android.content.Intent
import android.graphics.Paint
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class LoginActivity : AppCompatActivity() {

    lateinit var txtNewUser : TextView

    lateinit var txtForgotPass : TextView

    lateinit var btnLogin : Button


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        supportActionBar?.hide()

        txtNewUser = findViewById(R.id.txtNewUser_Login)

        txtForgotPass = findViewById(R.id.txtForgotPass_Login)

        btnLogin = findViewById(R.id.btn_Login)

        txtNewUser.paintFlags = Paint.UNDERLINE_TEXT_FLAG

        txtForgotPass.paintFlags = Paint.UNDERLINE_TEXT_FLAG

        txtNewUser.setOnClickListener {
            val i = Intent(this@LoginActivity,SignUpActivity::class.java)
            startActivity(i)
        }

        txtForgotPass.setOnClickListener{
            val i = Intent(this@LoginActivity,ForgotPassword::class.java)
            startActivity(i)
        }

       /* btnLogin.setOnClickListener {

            val i = Intent(this@LoginActivity,ForgotPassword::class.java)
            startActivity(i)

        }*/

    }
}